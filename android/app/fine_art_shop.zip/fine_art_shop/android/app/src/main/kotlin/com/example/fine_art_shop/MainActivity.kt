package com.example.fine_art_shop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
