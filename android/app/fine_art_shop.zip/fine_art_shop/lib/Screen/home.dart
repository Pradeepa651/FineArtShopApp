import 'package:fine_art_shop/Componets/cartmodel.dart';
import 'package:fine_art_shop/Componets/new_item_tile.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final auth = FirebaseAuth.instance;

  String username = "";

  @override
  void initState() {
    super.initState();
    getcurrentUser();
  }

  Future<void> getcurrentUser() async {
    try {
      final user = auth.currentUser;
      if (user != null) {
        setState(() {
          username = user.email!;
        });
      }
    } catch (e) {
      if (kDebugMode) {
        print(e);
      }
    }
  }

  List list = [1, 2, 30];

  @override
  Widget build(BuildContext context) {
    // return Scaffold(
    return Consumer<CartModel>(
        builder: (context, value, child) => Scaffold(
              backgroundColor: Colors.grey[100],
              appBar: AppBar(
                title: const Text("Rama"),
              ),
              body: Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 15.h,
                      ),
                      Text(
                        "Let's buy beautiful item for you",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 34.sp,
                        ),
                      ),
                      SizedBox(
                        height: 24.h,
                      ),
                      Wrap(
                        spacing: 4.w,
                        children: [
                          MaterialButton(
                              color: Colors.green,
                              onPressed: () =>
                                  Navigator.pushNamed(context, '/individual'),
                              child: const Text("individual")),
                          MaterialButton(
                              color: Colors.green,
                              onPressed: () => Navigator.pushNamed(
                                  context, '/specificscreen'),
                              child: const Text("specificscreen")),
                          MaterialButton(
                              color: Colors.green,
                              onPressed: () =>
                                  Navigator.pushNamed(context, '/cart'),
                              child: const Text("cart")),
                          MaterialButton(
                              color: Colors.green,
                              onPressed: () =>
                                  Navigator.pushNamed(context, '/individual2'),
                              child: const Text("individual2")),
                          MaterialButton(
                              color: Colors.green,
                              onPressed: () {
                                auth.signOut();
                                Navigator.pushNamed(context, '/signup');
                              },
                              child: const Text("logout")),
                        ],
                      ),
                      Text(
                        "Category",
                        style: TextStyle(
                          fontSize: 16.h,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      // Image.asset(
                      //   "assets/ramaicon2.png",
                      //   height: 64.h,
                      //   width: 20.w,
                      // ),
                      // //     Expanded(
                      // body: Column(children: [
                      Expanded(
                        child: GridView.builder(
                          itemCount: value.shopItem.length,
                          padding: EdgeInsets.symmetric(
                              horizontal: 5.w, vertical: 15.w),

                          // shrinkWrap: true,
                          // scrollDirection: Axis.vertical,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding:
                                  EdgeInsets.only(right: 15.w, bottom: 15.h),
                              child: NewItemTile(
                                itemName: value.shopItem[index][0],
                                itemPrice: value.shopItem[index][1],
                                imagePath: value.shopItem[index][2],
                                color: value.shopItem[index][3],
                              ),
                            );
                          },
                          scrollDirection: Axis.vertical,
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 2, childAspectRatio: 1 / 1.5),
                          // gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          //     crossAxisCount: 3),
                        ),
                      ),
                    ]),
              ),
            ));
  }
}
// Center(
// child: Text(
// "Shree Rama Jaya Ram Jaya Jaya Rama",
// style: TextStyle(
// fontSize: 16.sp,
// fontWeight: FontWeight.bold,
// ),
// ),
// ),
// Text(
// username,
// style: TextStyle(fontSize: 14.sp),
// ),
// SizedBox(
// height: 25.h,
// ),
// SizedBox(
// width: double.infinity,
// height: 30.h,
// child: ElevatedButton(
// onPressed: () {
// auth.signOut();
// Navigator.pushNamedAndRemoveUntil(
// context, '/login', (route) => false);
// },
// child: Text(
// "Log Out",
// style: TextStyle(
// fontSize: 14.sp,
// fontWeight: FontWeight.bold,
// ),
// )),
// ),
