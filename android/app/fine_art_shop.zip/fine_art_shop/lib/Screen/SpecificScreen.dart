import 'package:fine_art_shop/Componets/cartmodel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../Componets/new_item_tile.dart';

class SpecificScreen extends StatelessWidget {
  const SpecificScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.grey[100],
        appBar: AppBar(
          backgroundColor: Colors.brown[600],
          title: const Text("jai shree rama"),
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // SizedBox(
            //   height: 25.h,
            // ),
            Padding(
              padding: EdgeInsets.only(top: 25.h, left: 10.w),
              child: Text(
                "Recommended",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20.sp,
                ),
              ),
            ),
            Container(
              color: Colors.grey[300],
              height: 180.h,
              child: Consumer<CartModel>(
                builder: (context, value, child) => ListView.builder(
                  itemCount: value.shopItem.length,
                  padding: EdgeInsets.symmetric(
                    horizontal: 5.w,
                  ),
                  itemBuilder: (context, index) {
                    return SizedBox(
                      width: 150.w,
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: 10.w,
                          vertical: 10.h,
                        ),
                        child: NewItemTile(
                          itemName: value.shopItem[index][0],
                          itemPrice: value.shopItem[index][1],
                          imagePath: value.shopItem[index][2],
                          color: value.shopItem[index][3],
                        ),
                      ),
                    );
                  },
                  scrollDirection: Axis.horizontal,
                ),
              ),
            ),
            const Divider(thickness: 1.5),
            Padding(
              padding: EdgeInsets.only(left: 10.w, bottom: 5.h, top: 5.h),
              child: Text(
                "New",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20.sp,
                ),
              ),
            ),
            Expanded(
              child: Container(
                color: Colors.grey[300],
                child: Consumer<CartModel>(
                  builder: (context, value, child) => GridView.builder(
                    itemCount: value.shopItem.length,
                    padding:
                        EdgeInsets.symmetric(horizontal: 5.w, vertical: 5.h),

                    // shrinkWrap: true,
                    // scrollDirection: Axis.vertical,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: EdgeInsets.symmetric(
                            vertical: 15.h, horizontal: 20.w),
                        child: NewItemTile(
                          itemName: value.shopItem[index][0],
                          itemPrice: value.shopItem[index][1],
                          imagePath: value.shopItem[index][2],
                          color: value.shopItem[index][3],
                        ),
                      );
                    },
                    scrollDirection: Axis.horizontal,
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 1, childAspectRatio: 3 / 2),

                    // gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    //     crossAxisCount: 3),
                  ),
                ),
              ),
            ),
            // Expanded(
            //   // height: 350.h,
            //   child: Consumer<CartModel>(
            //     builder: (context, value, child) => ListView.builder(
            //       itemCount: value.shopItem.length,
            //       padding:
            //           EdgeInsets.symmetric(horizontal: 5.w, vertical: 15.w),
            //       itemBuilder: (context, index) {
            //         return Padding(
            //           padding: EdgeInsets.symmetric(
            //             horizontal: 30.h,
            //             vertical: 15.w,
            //           ),
            //           child: NewItemTile(
            //             itemName: value.shopItem[index][0],
            //             itemPrice: value.shopItem[index][1],
            //             imagePath: value.shopItem[index][2],
            //             color: value.shopItem[index][3],
            //           ),
            //         );
            //       },
            //       scrollDirection: Axis.vertical,
            //     ),
            //   ),
            // ),
          ],
        ));
  }
}
