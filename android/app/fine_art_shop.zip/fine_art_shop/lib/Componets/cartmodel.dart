import 'package:flutter/material.dart';

class CartModel extends ChangeNotifier {
  final List shopItem = [
    // [ itemName, itemPrice, imagePath, color ]
    ["Rama", "100000", "assets/ramaicon.jpeg", Colors.grey[50]],
    ["Rama", "100000", "assets/ramaicon.jpeg", Colors.grey[50]],
    ["Rama", "100000", "assets/ramaicon.jpeg", Colors.grey[50]],
    ["Rama", "100000", "assets/ramaicon.jpeg", Colors.grey[50]],
    ["Rama", "100000", "assets/ramaicon.jpeg", Colors.grey[50]],
    ["Rama", "100000", "assets/ramaicon.jpeg", Colors.grey[50]],
    ["Rama", "100000", "assets/ramaicon.jpeg", Colors.grey[50]],
    ["Rama", "100000", "assets/ramaicon.jpeg", Colors.grey[50]],
  ];
  get shopItems => shopItem;
}
