import 'package:fine_art_shop/Screen/Login.dart';
import 'package:fine_art_shop/Screen/SpecificScreen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'Componets/cartmodel.dart';
import 'Screen/Cart.dart';
import 'Screen/Indidual.dart';
import 'Screen/Indidual2.dart';
import 'Screen/SignUp.dart';
import 'Screen/StartScreen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:fine_art_shop/Screen/ForgotPassword.dart';
import 'package:fine_art_shop/Screen/home.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
        designSize: const Size(360, 640),
        minTextAdapt: true,
        splitScreenMode: true,
        builder: (context, child) {
          return MultiProvider(
            providers: [ChangeNotifierProvider(create: (_) => CartModel())],
            child: MaterialApp(
              title: 'Flutter Demo',
              // theme: ThemeData(
              //     primarySwatch: Colors.blue,
              //     textTheme: GoogleFonts.nunitoTextTheme(
              //       Theme.of(context).textTheme,
              //     )),
              initialRoute: '/',
              routes: {
                '/': (context) => StartScreen(),
                '/signup': (context) => SignUp(),
                '/login': (context) => Login(),
                '/forgotpassword': (context) => ForgotPassword(),
                '/home': (context) => Home(),
                '/specificscreen': (context) => SpecificScreen(),
                '/individual': (context) => Individual(),
                '/individual2': (context) => Individual2(),
                '/cart': (context) => Cart(),
              },
            ),
          );
        });
  }
}
