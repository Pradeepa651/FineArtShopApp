import 'package:flutter/material.dart';

final purpleColor = Color(0xff6688FF);
final darkTextColor = Color(0xff1F1A3D);
final lightTextColor = Color(0xff999999);
final textFieldColor = Color(0xffF5F6FA);
final borderColor = Colors.black12;
